<?php
/**
 * The Local_Seo Module
 *
 * @since      1.0.0
 * @package    RankMath
 * @subpackage RankMathPro
 * @author     Rank Math <support@rankmath.com>
 */

namespace RankMathPro\Local_Seo;

use RankMath\Helper;
use RankMath\Post;
use RankMath\Traits\Hooker;
use RankMath\Schema\DB;

defined( 'ABSPATH' ) || exit;

/**
 * Frontend class.
 */
class Frontend {

	use Hooker;

	/**
	 * The Constructor.
	 */
	public function __construct() {
		$this->action( 'rank_math/json_ld', 'add_location_schema', 11 );
		$this->action( 'rank_math/head', 'add_location_tags', 90 );

		new Search();
	}

	/**
	 * Add Locations Metatags to head.
	 */
	public function add_location_tags() {
		if ( ! is_singular( 'rank_math_locations' ) ) {
			return;
		}

		$schema = DB::get_schemas( Post::get_simple_page_id() );
		if ( empty( $schema ) ) {
			return;
		}
		$schema    = current( $schema );
		$meta_tags = [
			'placename' => ! empty( $schema['address']['addressLocality'] ) ? $schema['address']['addressLocality'] : '',
			'position'  => ! empty( $schema['geo']['latitude'] ) ? $schema['geo']['latitude'] . ';' . $schema['geo']['longitude'] : '',
			'region'    => ! empty( $schema['address']['addressCountry'] ) ? $schema['address']['addressCountry'] : '',
		];

		foreach ( $meta_tags as $name => $value ) {
			if ( ! $value ) {
				continue;
			}

			printf( '<meta name="geo.%1$s" content="%2$s" />' . "\n", esc_attr( $name ), esc_attr( $value ) );
		}
	}

	/**
	 * Add Locations Schema.
	 *
	 * @param array $data Array of json-ld data.
	 *
	 * @return array
	 */
	public function add_location_schema( $data ) {
		if (
			! is_singular( 'rank_math_locations' ) ||
			empty( $data['publisher'] ) ||
			! Helper::get_settings( 'titles.same_organization_locations', false )
		) {
			return $data;
		}

		global $post;
		$schema_key = key( DB::get_schemas( $post->ID ) );
		if ( ! isset( $data[ $schema_key ] ) ) {
			return $data;
		}

		$data[ $schema_key ]['parentOrganization'] = [ '@id' => $data['publisher']['@id'] ];

		return $data;
	}
}
